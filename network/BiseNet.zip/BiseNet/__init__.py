
from .bisenetv2_1 import BiSeNetV2_1
from .bisenetv2_3 import BiSeNetV2_3
